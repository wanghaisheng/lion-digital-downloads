const Index = (props) => {
    
  return(
    <div>
      hello
    </div>
  )
}

export const Index;
